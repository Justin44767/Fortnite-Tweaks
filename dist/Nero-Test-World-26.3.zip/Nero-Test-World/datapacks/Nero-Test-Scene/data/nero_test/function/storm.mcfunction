weather thunder
time set 6000
