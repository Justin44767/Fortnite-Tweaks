execute unless data storage nero_test:state initialized run function nero_test:init
