weather clear
time set 18000
