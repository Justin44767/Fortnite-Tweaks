data modify storage nero_test:state initialized set value 1b
forceload add -48 -48 48 48
schedule function nero_test:build 40t replace
