# Only for the supplied NEW test world: replaces blocks around 0 64 0.
weather clear
time set 6000
fill -40 65 -40 40 68 40 air
fill -40 69 -40 40 72 40 air
fill -40 73 -40 40 76 40 air
fill -40 77 -40 40 80 40 air
fill -40 81 -40 40 84 40 air
fill -40 85 -40 40 88 40 air
fill -40 89 -40 40 92 40 air
fill -40 93 -40 40 96 40 air
fill -40 97 -40 40 100 40 air
fill -40 61 -40 40 63 40 stone
fill -40 64 -40 40 64 40 grass_block
fill -25 64 -20 5 64 12 sand
fill -24 63 -19 4 63 11 sand
fill -23 64 -18 3 64 10 water
fill -18 62 -13 -2 63 4 water
fill -18 61 -13 -2 61 4 sand
fill -28 65 14 18 65 17 stone_bricks
fill 10 65 -8 14 69 -4 glass
fill 11 66 -7 13 68 -5 air
fill 17 65 -8 19 67 -6 iron_block
fill 23 65 -8 25 67 -6 copper_block
fill 29 65 -8 31 67 -6 gold_block
fill 10 65 -17 15 67 -15 red_stained_glass
fill 20 65 -17 25 67 -15 blue_stained_glass
fill 15 65 -34 35 70 -23 stone
fill 19 71 -33 32 76 -25 stone
fill 23 77 -31 29 82 -27 stone
fill 24 83 -30 28 83 -28 snow_block
fill -36 65 -35 -29 70 -28 stone
fill -35 71 -34 -30 73 -29 stone
fill -6 65 20 6 65 30 smooth_stone
fill -31 69 -16 -27 71 -12 oak_leaves[persistent=true]
fill -30 72 -15 -28 72 -13 oak_leaves[persistent=true]
fill -29 65 -14 -29 70 -14 oak_log
setblock -26 65 -13 short_grass
fill -32 69 -2 -28 71 2 oak_leaves[persistent=true]
fill -31 72 -1 -29 72 1 oak_leaves[persistent=true]
fill -30 65 0 -30 70 0 oak_log
setblock -27 65 1 short_grass
fill -19 69 14 -15 71 18 oak_leaves[persistent=true]
fill -18 72 15 -16 72 17 oak_leaves[persistent=true]
fill -17 65 16 -17 70 16 oak_log
setblock -14 65 17 short_grass
fill -9 69 -27 -5 71 -23 oak_leaves[persistent=true]
fill -8 72 -26 -6 72 -24 oak_leaves[persistent=true]
fill -7 65 -25 -7 70 -25 oak_log
setblock -4 65 -24 short_grass
fill 5 69 -31 9 71 -27 oak_leaves[persistent=true]
fill 6 72 -30 8 72 -28 oak_leaves[persistent=true]
fill 7 65 -29 7 70 -29 oak_log
setblock 10 65 -28 short_grass
fill 17 69 1 21 71 5 oak_leaves[persistent=true]
fill 18 72 2 20 72 4 oak_leaves[persistent=true]
fill 19 65 3 19 70 3 oak_log
setblock 22 65 4 short_grass
fill 27 69 6 31 71 10 oak_leaves[persistent=true]
fill 28 72 7 30 72 9 oak_leaves[persistent=true]
fill 29 65 8 29 70 8 oak_log
setblock 32 65 9 short_grass
setblock -25 66 15 torch
setblock -25 65 19 oak_fence
setblock -25 66 19 lantern
setblock -15 66 15 torch
setblock -15 65 19 oak_fence
setblock -15 66 19 lantern
setblock -5 66 15 torch
setblock -5 65 19 oak_fence
setblock -5 66 19 lantern
setblock 5 66 15 torch
setblock 5 65 19 oak_fence
setblock 5 66 19 lantern
setblock 15 66 15 torch
setblock 15 65 19 oak_fence
setblock 15 66 19 lantern
setblock 12 65 4 soul_lantern
setblock 15 65 4 sea_lantern
data modify storage nero_test:state built set value 1b
function nero_test:camera_water
tellraw @a {"text":"NERO test scene built. Use /function nero_test:camera_water or camera_forest, then compare shaders OFF/ON.","color":"aqua"}
forceload remove -48 -48 48 48
