weather clear
time set 6000
