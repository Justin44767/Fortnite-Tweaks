weather rain
time set 6000
