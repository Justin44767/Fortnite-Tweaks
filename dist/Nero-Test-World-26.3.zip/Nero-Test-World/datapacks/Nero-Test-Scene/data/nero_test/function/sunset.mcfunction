weather clear
time set 12500
