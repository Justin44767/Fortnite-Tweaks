execute in minecraft:the_end run tp @s 0 80 0
