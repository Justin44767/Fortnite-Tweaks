execute in minecraft:the_nether run tp @s 0 90 0
